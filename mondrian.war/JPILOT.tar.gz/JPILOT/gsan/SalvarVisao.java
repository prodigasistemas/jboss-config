package gsan;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tonbeller.wcf.bookmarks.BookmarkManager;

public class SalvarVisao extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {

		try {

			Object state = BookmarkManager.instance(request.getSession())
					.collectSessionState(0);

			HttpSession session = request.getSession();
			
			ServletOutputStream servletOut = response.getOutputStream();

			XMLEncoder e = new XMLEncoder(new BufferedOutputStream(servletOut));

			String tituloRelatorio = (String) session.getAttribute("parametro");

			response.setContentType("text/xml");
			response.addHeader("Content-Disposition",
					"attachment; filename=VisaoMondrian"
							+ (tituloRelatorio == null ? "" : tituloRelatorio)
							+ ".xml");

			e.writeObject(state);

			e.close();

			servletOut.flush();

			servletOut.close();

		} catch (IOException e) {

		}

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		this.doGet(req, res);
	}

}
