package gsan;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;

import com.tonbeller.wcf.bookmarks.BookmarkManager;

public class RestaurarVisao extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		byte[] uploadVisao = null;

		DiskFileUpload upload = new DiskFileUpload();
		List items = null;
		try {
			items = upload.parseRequest(request);
		} catch (FileUploadException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(items);
		if (items != null) {

			FileItem item = null;

			Iterator iter = items.iterator();
			while (iter.hasNext()) {
				item = (FileItem) iter.next();
				System.out.println("Entrou items");
				if (item.getFieldName().equals("uploadVisao")) {
					System.out.println("entrou field");
					if (item.get().length != 0) {
						// condiciona ao arquivo ser do tipo XML
						if (item.getName().toUpperCase().endsWith(".XML")) {
							// condiciona o arquivo ser menor que 200Kb ou
							// 204800 Bytes
							if (item.getSize() < 204800) {
								System.out.println("pegou arquivo");
								uploadVisao = item.get();
							} else {
								break;
							}

						} else {
							break;
						}
					}
				}

				XMLDecoder d = null;

				
				d = new XMLDecoder(new BufferedInputStream(
						new ByteArrayInputStream(uploadVisao)));

				Object state = d.readObject();

				d.close();

				BookmarkManager.instance(request.getSession())
						.restoreSessionState(state);

			}

		}

		getServletConfig().getServletContext().getRequestDispatcher("/testpage.jsp").include(request,response);
		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		this.doGet(req, res);
	}

}
